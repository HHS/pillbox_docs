class PillCategory < ActiveRecord::Base
  has_many :pills
end
