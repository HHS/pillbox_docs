class Move < ActiveRecord::Base
end
