require 'test_helper'

class PillsHelperTest < ActionView::TestCase
end
