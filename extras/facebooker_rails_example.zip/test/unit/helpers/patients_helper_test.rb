require 'test_helper'

class PatientsHelperTest < ActionView::TestCase
end
